<!-- ======= Header ======= -->
<header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      
      <a href="/index" class="navbar-brand es-logo">
        <img src="img/esschool.png" width="200px" height="auto">
      </a>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="active" href="index.html">Paket Belajar</a></li>
          <li><a href="#">Program</a></li>
          <li><a href="#">Fitur</a></li>
          <li><a href="#">Artikel</a></li>
          <li><a href="#">Karir</a></li>
          <li><a href="#">Sahabat esschool.id</a></li>

          
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      

    </div>
  </header><!-- End Header -->
<?php /**PATH F:\project\escol\resources\views/components/header.blade.php ENDPATH**/ ?>